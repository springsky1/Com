<template>
  <div>
    <router-link to="/">主页</router-link>
  </div>  
</template>

<script>
  export default {
    name: ''
  }
</script>