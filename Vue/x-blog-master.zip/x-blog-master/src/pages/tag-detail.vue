<template>
  <article class="tag-page">
    this is tag detail page
  </article>
</template>
<script>
  const COMPONENT_NAME = 'tag-page';
  export default {
    name: COMPONENT_NAME
  } 
</script>

<style>

</style>