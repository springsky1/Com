using Microsoft.Extensions.Logging;

namespace HyperaiShell.App.Logging
{
    public class ReConsoleLoggerOptions
    {
        public LogLevel MinmalLevel { get; set; } = LogLevel.Debug;
    }
}