﻿using System.Collections.ObjectModel;

namespace HyperaiShell.Foundation.Bots
{
    public class BotCollection : Collection<BotBase>
    {
    }
}