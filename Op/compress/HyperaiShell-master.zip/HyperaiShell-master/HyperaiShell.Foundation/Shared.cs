﻿using Hyperai;

namespace HyperaiShell.Foundation
{
    public static class Shared
    {
        public static IHyperaiApplication Application { get; set; }
    }
}