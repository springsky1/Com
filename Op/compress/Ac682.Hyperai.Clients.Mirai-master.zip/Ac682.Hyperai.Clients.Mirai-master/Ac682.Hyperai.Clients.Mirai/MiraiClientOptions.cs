﻿namespace Ac682.Hyperai.Clients.Mirai
{
    public class MiraiClientOptions
    {
        public string AuthKey { get; set; }
        public int Port { get; set; }
        public string Host { get; set; }
        public long SelfQQ { get; set; }
    }
}