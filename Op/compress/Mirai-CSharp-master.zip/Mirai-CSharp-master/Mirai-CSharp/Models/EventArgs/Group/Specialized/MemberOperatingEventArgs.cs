﻿namespace Mirai_CSharp.Models
{
    /// <summary>
    /// 提供成员被踢出群相关信息的接口。继承自 <see cref="IMemberEventArgs"/>
    /// </summary>
    public interface IGroupMemberKickedEventArgs : IMemberOperatingEventArgs
    {

    }
}
